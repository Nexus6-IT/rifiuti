# @testing-umano/motore

Esegue le invarianti di `testing/spec.yaml` in sola lettura sullo staging.
Specifica: `../docs/superpowers/specs/2026-10-12-testing-umano-strumento-design.md`.

    npm test                       # unitari + integrazione (Docker: Ubuntu WSL acceso, DOCKER_HOST=tcp://localhost:2375)
    bash scripts/vendorizza.sh <repo>   # tarball in <repo>/testing/vendor/

Nel progetto:

    npm install --no-save ../testing/vendor/testing-umano-motore-<versione>.tgz
    npx testing-umano verifica --dir ../testing --tenant <id>

Primo avvio su un progetto nuovo (legge solo il catalogo, non serve il marcatore):

    TESTING_PG_URL=postgresql://... npx testing-umano init --dir testing             # mostra, non scrive
    TESTING_PG_URL=postgresql://... npx testing-umano init --dir testing --conferma  # scrive

`init` genera `testing/spec.yaml` con i controlli universali (isolamento dei tenant,
riferimenti senza FK, numerazioni senza buchi), tutti `in-attesa`, e in `testing/init/`
l'SQL del ruolo in sola lettura, il marcatore e il workflow Gitea da copiare.
Non sovrascrive mai uno `spec.yaml` esistente. Le colonne `_id` che il nome non
spiega si collegano con `--collega tabella.colonna=tabella`.
